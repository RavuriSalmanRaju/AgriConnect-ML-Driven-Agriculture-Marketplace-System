<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['farmer_id'])) {
    header("Location: login.php");
    exit();
}

$fid = $_SESSION['farmer_id'];
$fname = $_SESSION['farmer_name'] ?? "Farmer";

// Send query to admin
if(isset($_POST['msg'])){
    $msg = $conn->real_escape_string($_POST['msg']);

    $conn->query("INSERT INTO support_tickets(user_role,user_id,user_name,message)
                  VALUES('FARMER',$fid,'$fname','$msg')");

    header("Location: chatbot.php");
    exit();
}

// Fetch farmer tickets
$tickets = $conn->query("SELECT * FROM support_tickets 
                         WHERE user_role='FARMER' AND user_id=$fid
                         ORDER BY ticket_id DESC");
?>
<!DOCTYPE html>
<html>
<head>
<title>Farmer Chat Support</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-3 text-end">
  <a href="dashboard.php" class="btn btn-outline-success">⬅ Back</a>
</div>

<div class="container my-4">
<h4 class="fw-bold">💬 Farmer Chat Support</h4>
<p class="text-muted">Send your issue to admin, admin will reply.</p>

<form method="POST" class="mb-4">
  <textarea name="msg" class="form-control" placeholder="Type your query..." required></textarea>
  <button class="btn btn-success mt-2">Send to Admin</button>
</form>

<div class="card shadow-sm">
  <div class="card-body">
    <h5 class="fw-bold mb-3">📩 My Queries</h5>

    <?php if($tickets && $tickets->num_rows>0){ ?>
      <?php while($t=$tickets->fetch_assoc()){ ?>
        <div class="border rounded p-3 mb-3">
          <b>My Message:</b> <?php echo $t['message']; ?><br>
          <small class="text-muted"><?php echo $t['created_at']; ?></small>

          <hr>
          <b>Admin Reply:</b>
          <?php if($t['admin_reply']!=NULL){ ?>
            <span class="text-success"><?php echo $t['admin_reply']; ?></span>
          <?php } else { ?>
            <span class="text-danger">Pending...</span>
          <?php } ?>
        </div>
      <?php } ?>
    <?php } else { ?>
      <p class="text-muted">No queries yet.</p>
    <?php } ?>

  </div>
</div>

</div>
</body>
</html>
