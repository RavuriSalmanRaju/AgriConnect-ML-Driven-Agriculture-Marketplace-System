<?php
include("config/db.php");

echo "Database Connected ✅";
?>
