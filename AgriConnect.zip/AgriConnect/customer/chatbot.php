<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['customer_id'])) {
    header("Location: login.php");
    exit();
}

$cid = $_SESSION['customer_id'];
$cname = $_SESSION['customer_name'] ?? "Customer";

// Send query to admin
if(isset($_POST['msg'])){
    $msg = $conn->real_escape_string($_POST['msg']);

    $conn->query("INSERT INTO support_tickets(user_role,user_id,user_name,message)
                  VALUES('CUSTOMER',$cid,'$cname','$msg')");

    header("Location: chatbot.php");
    exit();
}

// Fetch customer tickets
$tickets = $conn->query("SELECT * FROM support_tickets 
                         WHERE user_role='CUSTOMER' AND user_id=$cid
                         ORDER BY ticket_id DESC");
?>
<!DOCTYPE html>
<html>
<head>
<title>Customer Chat Support</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-3 text-end">
  <a href="dashboard.php" class="btn btn-outline-success">⬅ Back</a>
</div>

<div class="container my-4">
<h4 class="fw-bold">💬 Customer Chat Support</h4>
<p class="text-muted">Send your query to Admin, Admin will reply.</p>

<form method="POST" class="mb-4">
  <textarea name="msg" class="form-control" placeholder="Type your query..." required></textarea>
  <button class="btn btn-success mt-2">Send to Admin</button>
</form>

<div class="card shadow-sm">
  <div class="card-body">
    <h5 class="fw-bold mb-3">📩 My Queries</h5>

    <?php if($tickets && $tickets->num_rows>0){ ?>
      <?php while($t=$tickets->fetch_assoc()){ ?>
        <div class="border rounded p-3 mb-3">
          <b>My Message:</b> <?php echo $t['message']; ?><br>
          <small class="text-muted"><?php echo $t['created_at']; ?></small>

          <hr>
          <b>Admin Reply:</b>
          <?php if($t['admin_reply']!=NULL){ ?>
            <span class="text-success"><?php echo $t['admin_reply']; ?></span>
          <?php } else { ?>
            <span class="text-danger">Pending...</span>
          <?php } ?>
        </div>
      <?php } ?>
    <?php } else { ?>
      <p class="text-muted">No queries yet.</p>
    <?php } ?>

  </div>
</div>

</div>
</body>
</html>
